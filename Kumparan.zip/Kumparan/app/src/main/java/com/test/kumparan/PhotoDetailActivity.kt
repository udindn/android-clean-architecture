package com.test.kumparan

import android.os.Bundle
import android.transition.Transition
import android.view.LayoutInflater
import android.view.MenuItem
import com.squareup.picasso.Picasso
import com.test.core.domain.model.PhotoModel
import com.test.core.ui.BaseActivity
import com.test.kumparan.databinding.ActivityPhotoDetailBinding

class PhotoDetailActivity : BaseActivity<ActivityPhotoDetailBinding>() {

    companion object {
        const val EXTRA_DATA = "extra_data"
    }

    private lateinit var photoModel: PhotoModel

    override val bindingInflater: (LayoutInflater) -> ActivityPhotoDetailBinding
        get() = ActivityPhotoDetailBinding::inflate

    override fun setup(savedInstanceState: Bundle?) {
        initExtras()
        setupToolbar(
            R.id.toolbar,
            true,
            photoModel.title,
            R.color.colorRed,
            4f
        )
    }

    private fun initExtras() {
        if (intent != null && intent.hasExtra(EXTRA_DATA)) {
            photoModel = intent.getParcelableExtra(EXTRA_DATA)!!

            Picasso.get().load(photoModel.url).noFade().into(binding.imageView)
//
//        //add transition listener to load full-size image on transition end
            window.sharedElementEnterTransition.addListener(object : Transition.TransitionListener {
                override fun onTransitionEnd(transition: Transition?) {
                    //load full-size
                    Picasso.get().load(photoModel.url).noFade().noPlaceholder().into(binding.imageView)
                    transition?.removeListener(this)
                }

                override fun onTransitionResume(transition: Transition?) {
                    //To change body of created functions use File | Settings | File Templates.
                }

                override fun onTransitionPause(transition: Transition?) {
                    //To change body of created functions use File | Settings | File Templates.
                }

                override fun onTransitionCancel(transition: Transition?) {
                    //To change body of created functions use File | Settings | File Templates.
                }

                override fun onTransitionStart(transition: Transition?) {
                    //To change body of created functions use File | Settings | File Templates.
                }
            })
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
            }
        }
        return super.onOptionsItemSelected(item)
    }
}