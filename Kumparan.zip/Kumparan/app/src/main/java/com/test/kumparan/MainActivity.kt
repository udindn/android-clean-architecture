package com.test.kumparan

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.test.core.data.Resource
import com.test.core.domain.model.PostModel
import com.test.core.domain.model.UserModel
import com.test.core.ui.BaseActivity
import com.test.kumparan.adapter.MainAdapter
import com.test.kumparan.databinding.ActivityMainBinding
import com.test.kumparan.viewmodel.PostViewModel
import org.koin.android.viewmodel.ext.android.viewModel

class MainActivity : BaseActivity<ActivityMainBinding>() {

    private val postViewModel: PostViewModel by viewModel()
    private lateinit var postAdapter: MainAdapter
    private var postList: List<PostModel>? = arrayListOf()
    private var userList: List<UserModel>? = arrayListOf()
    private var loadDataIsComplete = arrayOf(false, false)

    override val bindingInflater: (LayoutInflater) -> ActivityMainBinding
        get() = ActivityMainBinding::inflate

    override fun setup(savedInstanceState: Bundle?) {
        setupToolbar(
            R.id.toolbar,
            false,
            "Main Menu",
            R.color.colorRed,
            4f
        )

        getResponse()
        setupRecyclerView()
        initOnClick()
    }

    private fun getResponse() {
        postAdapter = MainAdapter()
        postViewModel.post.observe(this, { post ->
            if (post != null) {
                when (post) {
                    is Resource.Loading -> {
                        binding.pbLoadListPost.visibility = View.VISIBLE
                    }
                    is Resource.Success -> {
                        binding.pbLoadListPost.visibility = View.GONE
                        postList = post.data
                        loadDataIsComplete[0] = true
                        validateSetupRecyclerView()
                    }
                    is Resource.Error -> {
                        binding.pbLoadListPost.visibility = View.GONE
                        postList = post.data
                        loadDataIsComplete[0] = true
                        validateSetupRecyclerView()
                    }
                }
            }
        })

        postViewModel.user.observe(this, { user ->
            if (user != null) {
                when (user) {
                    is Resource.Loading -> {
                        binding.pbLoadListPost.visibility = View.VISIBLE
                    }
                    is Resource.Success -> {
                        binding.pbLoadListPost.visibility = View.GONE
                        userList = user.data
                        loadDataIsComplete[1] = true
                        validateSetupRecyclerView()
                    }
                    is Resource.Error -> {
                        binding.pbLoadListPost.visibility = View.GONE
                        userList = user.data
                        loadDataIsComplete[1] = true
                        validateSetupRecyclerView()
                    }
                }
            }
        })
    }

    private fun setupRecyclerView() {
        with(binding.rvPostList) {
            layoutManager = LinearLayoutManager(context)
            setHasFixedSize(true)
            adapter = postAdapter
        }
    }

    private fun validateSetupRecyclerView() {
        if (loadDataIsComplete.all { it }) {
            for (user in userList!!) {
                for (post in postList!!) {
                    if (user.id == post.userId) {
                        post.name = user.name
                        post.company = user.companyName
                    }
                }
            }
            postAdapter.setData(postList)
        }
    }

    private fun initOnClick() {
        postAdapter.onItemClick = { selectedData, type ->
            if (type == MainAdapter.POST) {
                val intent = Intent(this, PostDetailActivity::class.java)
                intent.putExtra(PostDetailActivity.EXTRA_DATA, selectedData)
                startActivity(intent)
            } else {
                val intent = Intent(this, ProfileDetailActivity::class.java)
                intent.putExtra(PostDetailActivity.EXTRA_DATA, selectedData.userId)
                startActivity(intent)
            }
        }
    }
}