package com.test.core.domain.usecase

import com.test.core.data.Resource
import com.test.core.domain.model.*
import kotlinx.coroutines.flow.Flow

interface ContentUseCase {

    fun getAllPost(): Flow<Resource<List<PostModel>>>

    fun getAllPostFromDB() : Flow<List<PostModel>>

    fun getAllUserFromDB() : Flow<List<UserModel>>

    fun getUserById(userId: Int) : Flow<Resource<UserModel>>

    fun getAllUser(): Flow<Resource<List<UserModel>>>

    fun getCommentByPostId(postId: Int): Flow<Resource<List<CommentModel>>>

    fun getAlbumByUserId(userId: Int): Flow<Resource<List<AlbumModel>>>

    fun getPhotoByAlbumId(albumId: Int): Flow<Resource<List<PhotoModel>>>
}